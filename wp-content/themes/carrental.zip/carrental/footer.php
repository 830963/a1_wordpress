</main>
</div>
<footer id="footer" role="contentinfo">

<footer class="footer">
        <div class="container">
            <p>&copy; 2023 CarRental. All rights reserved.</p>
        </div>
    </footer>
</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>